package com.revature.testing;

import java.lang.reflect.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.revature.models.Customer;
import com.revature.orm.ORM;

public class CustomerTest 
{
	public static void main(String args[]) throws SQLException, IOException, IllegalAccessException
	{
		Scanner scan = new Scanner(System.in);
		String input = scan.nextLine();
		try 
		{
			Class<?> clazz = Class.forName(input);
			System.out.println(clazz);
			
		} catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ORM<Customer> or = new ORM<>(Customer.class);
		Object o = or.selectByID(new Customer(), 1);
		System.out.println(o);
		
		List<Customer> cusList = new ArrayList<>();
		cusList = or.selectAll(new Customer());
		System.out.println(cusList);
	}
}
