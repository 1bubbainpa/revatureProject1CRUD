package com.revature.controllers;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.revature.models.Customer;
import com.revature.orm.ORM;

public class Controller<T>
{
	ORM or;
    Gson gson = new Gson();
    
    public Controller(ORM or)
    {
    	this.or = or;
    }
    
	public void getById(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException
	{
		String input = request.getAttribute("id").toString();
		//String type = request.getAttribute("name").toString();
		
	    int id = 0;
	    if(input.matches("[0-9]+")) 
	    {
	        id = Integer.parseInt(input);
	    } 
	    else 
	    {
	        response.sendError(400, "ID is not a number");
	        return;
	    }
	    
	    //Object o = null;
		try 
		{
			Object o = or.selectByID(new Customer(), id);
			response.getWriter().append((o != null) ? gson.toJson(o): "{}");
		} 
		catch (IllegalAccessException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void getAll(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		List<Customer> cusList = new ArrayList<>();
		cusList = or.selectAll(new Customer());
		response.getWriter().append(gson.toJson(cusList));
	}
	
	public void addObject(HttpServletRequest request, HttpServletResponse response) throws IOException, IllegalAccessException
	{
		//Extract data/information from the request
        BufferedReader reader = request.getReader();
        Customer c = gson.fromJson(reader, Customer.class);

        //Call some service(s) to process the data/information
        or.create(c);

        //Generate a response from that processed data.
        if(c != null) {
            response.setStatus(201);
            response.getWriter().append(gson.toJson(c));
        } else {
            response.getWriter().append("{}");
        }
	}
	
	public void updateObject(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		Customer c = gson.fromJson(request.getReader(), Customer.class);
        c.setId((int) request.getAttribute("id"));

        try 
        {
			or.update(c);
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        response.getWriter().append((c != null) ? gson.toJson(c) : "{}");
	}
	
	public void deleteObject(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		Customer c = gson.fromJson(request.getReader(), Customer.class);
		int id = (int) request.getAttribute("id");

        try {
			or.deleteByID(c, id);
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        response.getWriter().append((c != null) ? gson.toJson(c) : "{}");
        response.setStatus(204);
	}
}
