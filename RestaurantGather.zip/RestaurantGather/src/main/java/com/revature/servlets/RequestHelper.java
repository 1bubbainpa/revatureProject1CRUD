package com.revature.servlets;

import com.revature.controllers.Controller;
import com.revature.models.Customer;
import com.revature.orm.ORM;
import com.revature.utilities.ResourceNotFoundException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;

//This Class is acting as a Delegator - to tell our code where it should be processed next.
public class RequestHelper {

    //This is us trying to use Dependency Injection to help decouple our classes from having to manage
    // Objects (dependencies) that they need
	
	//Implement our ORM here
	//May need to add another class
	
    //*static ORM mr = new MovieRepoDBImpl();
    //*static MovieService ms = new MovieServiceImpl(mr);
    //*static MovieController mc = new MovieController(ms);

    /**
     * This method will delegate other methods on the Controller layer of our application
     * to process the request
     * @param request - the HTTP Request
     * @param response - the HTTP Response
     * @throws SQLException 
     * @throws IllegalAccessException 
     * @throws InstantiationException 
     */
    public static void getProcess(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, SQLException, InstantiationException, IllegalAccessException {

        String uri = request.getRequestURI();
        System.out.println(uri);

        String[] uriTokens = uri.split("/");
        System.out.println(Arrays.toString(uriTokens));

        switch (uriTokens.length) 
        {
            //if the uriTokens only has two elements, a blank element and the project name, then nothing to process.
            case 0:
            case 1:
            case 2: {
                response.sendError(404);
                break;
            }
            //if the uriTokens is exactly 3 then it also has the collection name, but no path parameter.
            case 3: {
                //Call our getAll<Insert Entity Here> methods.
                if(("customer").equals(uriTokens[2])) 
                {
                	//uriTokens[2].getAttributes();
                	ORM<Customer> cusORM = new ORM<>(Customer.class);
                	Controller cn = new Controller(cusORM);
                	cn.getAll(request, response);
                }
                else //if(("reservation").equals(uriTokens[2]))
                {
                	response.sendError(400, "Collection does not exist");
                }
                break;
            }
            case 4: {
            	request.setAttribute("id", uriTokens[3]);
            	ORM<Customer> cusORM = new ORM<>(Customer.class);
            	Controller cn = new Controller(cusORM);
            	cn.getById(request, response);
                request.setAttribute("id", uriTokens[3]);
                //*if(("movies").equals(uriTokens[2])) mc.getMovieById(request, response);
                break;
            }
            default: {
                response.sendError(400);
                break;
            }
        }

    }

    public static void postProcess(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException, IllegalAccessException {


        String uri = request.getRequestURI();
        System.out.println(uri);

        String[] uriTokens = uri.split("/");
        System.out.println(Arrays.toString(uriTokens));

        switch (uriTokens.length) {
            //if the uriTokens only has two elements, a blank element and the project name, then nothing to process.
            case 0:
            case 1:
            case 2: {
                response.sendError(404);
                break;
            }
            //if the uriTokens is exactly 3 then it also has the collection name, but no path parameter.
            case 3: {
                //Call our add method.
                if (("customer").equals(uriTokens[2]))
                {
                	ORM<Customer> cusORM = new ORM<>(Customer.class);
                	Controller cn = new Controller(cusORM);
                	cn.addObject(request, response);
                }
                else 
                {
                	response.sendError(400, "Collection does not exist");
                }
                break;
            }
            default: {
                response.sendError(400);
                break;
            }

        }

    }

    public static void putProcess(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException {

        String uri = request.getRequestURI();
        System.out.println(uri);

        String[] uriTokens = uri.split("/");
        System.out.println(Arrays.toString(uriTokens));

        switch (uriTokens.length) {
            //if the uriTokens only has two elements, a blank element and the project name, then nothing to process.
            case 0:
            case 1:
            case 2: {
                response.sendError(404);
                break;
            }
            //if the uriTokens is exactly 3 then it also has the collection name, but no path parameter.
            case 4: {
                int id = 0;
                String input = uriTokens[3];

                if(input.matches("[0-9]+")) 
                {
                    id = Integer.parseInt(input);
                } else {
                    response.sendError(400, "ID is not a number");
                    return;
                }

                request.setAttribute("id", id);
                if (("customer").equals(uriTokens[2])) 
                {
                	ORM<Customer> cusORM = new ORM<>(Customer.class);
                	Controller cn = new Controller(cusORM);
                	cn.updateObject(request, response);
                }
                else 
                {
                	response.sendError(400, "Collection does not exist");
                }
                break;
            }
            default: {
                response.sendError(400);
                break;
            }

        }

    }

    public static void deleteProcess(HttpServletRequest request, HttpServletResponse response) throws IOException, ResourceNotFoundException, SQLException {

        String uri = request.getRequestURI();
        System.out.println(uri);

        String[] uriTokens = uri.split("/");
        System.out.println(Arrays.toString(uriTokens));

        switch (uriTokens.length) {
            //if the uriTokens only has two elements, a blank element and the project name, then nothing to process.
            case 0:
            case 1:
            case 2: {
                response.sendError(404);
                break;
            }
            //if the uriTokens is exactly 3 then it also has the collection name, but no path parameter.
            case 4: {
                int id = 0;
                String input = uriTokens[3];

                if(input.matches("[0-9]+")) {
                    id = Integer.parseInt(input);
                } else {
                    response.sendError(400, "ID is not a number");
                    return;
                }

                request.setAttribute("id", id);
                if (("customer").equals(uriTokens[2])) 
                {
                	ORM<Customer> cusORM = new ORM<>(Customer.class);
                	Controller cn = new Controller(cusORM);
                	cn.deleteObject(request, response);
                }
                else 
                {
                	response.sendError(400, "Collection does not exist");
                }
                break;
            }
            default: {
                response.sendError(400);
                break;
            }

        }
    }
}